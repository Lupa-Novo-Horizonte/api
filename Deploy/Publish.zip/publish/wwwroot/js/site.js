﻿if (window.location.href.indexOf("?iframe=true") != -1) {
    document.getElementById("body").classList.add("iframe");
}
else {
    document.getElementById("body").classList.remove("iframe");
}
