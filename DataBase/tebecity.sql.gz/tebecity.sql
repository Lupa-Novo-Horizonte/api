-- Adminer 4.8.1 MySQL 8.0.29 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `tebecity`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `newsText`;
CREATE TABLE `newsText` (
  `id` int NOT NULL AUTO_INCREMENT,
  `t1` varchar(500) NOT NULL,
  `t2` varchar(500) NOT NULL,
  `t3` varchar(500) NOT NULL,
  `generativeTool` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

TRUNCATE `newsText`;
INSERT INTO `newsText` (`id`, `t1`, `t2`, `t3`, `generativeTool`) VALUES
(1,	'Escreva uma notícia abordando as questões relacionadas à',	'Explore temas como segurança pública, criminalidade, acidentes, impacto na qualidade de vida dos moradores, ação insuficiente das autoridades, demanda por reparos urgentes e as consequências para o comércio local.',	'',	'local'),
(2,	'Crie um post sobre',	'Destaque os riscos à segurança, as experiências dos moradores e a necessidade imediata de reparos. Seja o porta-voz dessa situação crítica.',	'',	'local'),
(3,	'Escreva uma matéria sobre o problema urgente de',	'Relate o impacto na qualidade de vida dos moradores.',	'',	'local'),
(4,	'Escreva um post abordando os problemas relacionados à inoperância do serviço de',	'Conscientize a comunidade sobre a importância de abordar essa questão vital.',	'',	'local'),
(5,	'Escreva uma postagem para informar os cidadãos sobre o precário',	'Incentive a conscientização da comunidade e pressione as autoridades locais para melhorias urgentes nessa questão fundamental.',	'',	'local'),
(6,	'Relate os problemas identificados sobre',	'Juntos podemos transformar o Novo Horizonte em um lugar mais limpo e saudável!',	'',	'local'),
(7,	'Divulgue os dados capturados sobre',	'Destaque os problemas enfrentados pelos moradores nessa questão.',	'',	'local'),
(8,	'Moradores estão reportando problemas com',	'Recomende a importancia da cobrança sobre a qualidade do sistema público no bairro Novo Horizonte.',	'',	'local'),
(9,	'Há  relatos de  problemas com',	'Incentive o engajamento da comunidade, encorajando-os a relatar as preocupações às autoridades locais.',	'',	'local'),
(10,	'Utilize os dados reportados sobre',	'Juntos, podemos construir um bairro melhor.',	'',	'local'),
(11,	'Create a sentence max 50 words recommending me to write a post informing citizens about the poor',	'in Novo Horizonte neighborhood.',	'Write in portugues.',	'chatGPT'),
(12,	'Create a sentence max 60 words recommending me to write a news warning citizens about the problems with',	'in Novo Horizonte neighborhood.',	'Write in portugues.',	'chatGPT'),
(13,	'Create a sentence max 55 words suggesting me to write a news reporting the problems about',	'in Novo Horizonte neighborhood.',	'Write in portugues.',	'chatGPT');

-- 2023-08-21 22:38:09
