-- Adminer 4.8.1 MySQL 8.0.29 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;

USE `tebecity`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `newsPriority`;
CREATE TABLE `newsPriority` (
  `id` int NOT NULL AUTO_INCREMENT,
  `occurrenceId` int NOT NULL,
  `occurrenceType` varchar(24) NOT NULL,
  `weight` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `newsText`;
CREATE TABLE `newsText` (
  `id` int NOT NULL AUTO_INCREMENT,
  `t1` varchar(500) NOT NULL,
  `t2` varchar(500) NOT NULL,
  `t3` varchar(500) NOT NULL,
  `generativeTool` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- 2023-08-21 21:38:56
