-- Adminer 4.8.1 MySQL 8.0.29 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `tebecity`;

SET NAMES utf8;

DROP TABLE IF EXISTS `asphalt`;
CREATE TABLE `asphalt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `latitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `path` json DEFAULT NULL,
  `isPaved` bit(1) NOT NULL,
  `hasHoles` bit(1) NOT NULL,
  `hasPavedSidewalks` bit(1) NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user` (`user`),
  CONSTRAINT `asphalt_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `asphalt_ibfk_2` FOREIGN KEY (`status`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `collect`;
CREATE TABLE `collect` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `hasCollect` bit(1) NOT NULL,
  `howManyTimes` int NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user` (`user`),
  CONSTRAINT `collect_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `collect_ibfk_2` FOREIGN KEY (`status`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `light`;
CREATE TABLE `light` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `latitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `path` json DEFAULT NULL,
  `hasLight` bit(1) NOT NULL,
  `isItWorking` bit(1) NOT NULL,
  `hasLosesCable` bit(1) NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user` (`user`),
  CONSTRAINT `light_ibfk_1` FOREIGN KEY (`status`) REFERENCES `status` (`id`),
  CONSTRAINT `light_ibfk_2` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `newsPriority`;
CREATE TABLE `newsPriority` (
  `id` int NOT NULL AUTO_INCREMENT,
  `occurrenceId` int NOT NULL,
  `occurrenceType` varchar(24) NOT NULL,
  `weight` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `newsText`;
CREATE TABLE `newsText` (
  `id` int NOT NULL AUTO_INCREMENT,
  `t1` varchar(500) NOT NULL,
  `t2` varchar(500) NOT NULL,
  `t3` varchar(500) NOT NULL,
  `generativeTool` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `newsText` (`id`, `t1`, `t2`, `t3`, `generativeTool`) VALUES
(1,	'Escreva uma notícia abordando as questões relacionadas à',	'Explore temas como segurança pública, criminalidade, acidentes, impacto na qualidade de vida dos moradores, ação insuficiente das autoridades, demanda por reparos urgentes e as consequências para o comércio local.',	'',	'local'),
(2,	'Crie um post sobre',	'Destaque os riscos à segurança, as experiências dos moradores e a necessidade imediata de reparos. Seja o porta-voz dessa situação crítica.',	'',	'local'),
(3,	'Escreva uma matéria sobre o problema urgente de',	'Relate o impacto na qualidade de vida dos moradores.',	'',	'local'),
(4,	'Escreva um post abordando os problemas relacionados à inoperância do serviço de',	'Conscientize a comunidade sobre a importância de abordar essa questão vital.',	'',	'local'),
(5,	'Escreva uma postagem para informar os cidadãos sobre o precário',	'Incentive a conscientização da comunidade e pressione as autoridades locais para melhorias urgentes nessa questão fundamental.',	'',	'local'),
(6,	'Relate os problemas identificados sobre',	'Juntos podemos transformar o Novo Horizonte em um lugar mais limpo e saudável!',	'',	'local'),
(7,	'Divulgue os dados capturados sobre',	'Destaque os problemas enfrentados pelos moradores nessa questão.',	'',	'local'),
(8,	'Moradores estão reportando problemas com',	'Recomende a importancia da cobrança sobre a qualidade do sistema público no bairro Novo Horizonte.',	'',	'local'),
(9,	'Há  relatos de  problemas com',	'Incentive o engajamento da comunidade, encorajando-os a relatar as preocupações às autoridades locais.',	'',	'local'),
(10,	'Utilize os dados reportados sobre',	'Juntos, podemos construir um bairro melhor.',	'',	'local'),
(11,	'Create a sentence max 50 words recommending me to write a post informing citizens about the poor',	'in Novo Horizonte neighborhood.',	'Write in portugues.',	'chatGPT'),
(12,	'Create a sentence max 60 words recommending me to write a news warning citizens about the problems with',	'in Novo Horizonte neighborhood.',	'Write in portugues.',	'chatGPT'),
(13,	'Create a sentence max 55 words suggesting me to write a news reporting the problems about',	'in Novo Horizonte neighborhood.',	'Write in portugues.',	'chatGPT');

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `role` (`id`, `name`, `description`, `createdAt`) VALUES
(1,	'admin',	'',	'2021-03-15 13:42:34');

DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `service` int NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service` (`service`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`service`) REFERENCES `serviceType` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `serviceType`;
CREATE TABLE `serviceType` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `serviceType` (`id`, `description`) VALUES
(2,	'Cartório'),
(3,	'Posto de Gasolina'),
(4,	'Posto de Saúde'),
(5,	'Hospital'),
(6,	'Bombeiro'),
(7,	'Escola'),
(8,	'Praça Pública'),
(10,	'Área para Prática de Esportes');

DROP TABLE IF EXISTS `sewer`;
CREATE TABLE `sewer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `hasHomeSewer` bit(1) NOT NULL,
  `hasHomeCesspool` bit(1) NOT NULL,
  `hasSanitationProject` bit(1) NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user` (`user`),
  CONSTRAINT `sewer_ibfk_1` FOREIGN KEY (`status`) REFERENCES `status` (`id`),
  CONSTRAINT `sewer_ibfk_2` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `closed` bit(1) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `status` (`id`, `name`, `closed`, `createdAt`) VALUES
(1,	'Opened',	CONV('0', 2, 10) + 0,	'2023-08-02 19:36:25'),
(2,	'Pending',	CONV('0', 2, 10) + 0,	'2023-08-02 19:37:04'),
(3,	'Deleted',	CONV('0', 2, 10) + 0,	'2023-08-02 19:37:10');

DROP TABLE IF EXISTS `survey`;
CREATE TABLE `survey` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question01` varchar(1) NOT NULL,
  `question02` varchar(1) NOT NULL,
  `question03` varchar(1) NOT NULL,
  `question04` varchar(1) NOT NULL,
  `question05` varchar(1) NOT NULL,
  `question06` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `question07` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `question08` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `question09` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `question10` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `question11` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `trash`;
CREATE TABLE `trash` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `hasRoadCleanUp` bit(1) NOT NULL,
  `howManyTimes` int NOT NULL,
  `hasAccumulatedTrash` bit(1) NOT NULL,
  `hasLandWeeding` bit(1) NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user` (`user`),
  CONSTRAINT `trash_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `trash_ibfk_2` FOREIGN KEY (`status`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `lastName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `userName` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  `block` bit(1) NOT NULL DEFAULT b'0',
  `roleId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `roleId` (`roleId`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `user` (`id`, `firstName`, `lastName`, `userName`, `password`, `active`, `block`, `roleId`, `createdAt`) VALUES
(7,	'tiago',	'eduardo',	'tiago@gmail.com',	'202CB962AC59075B964B07152D234B70',	CONV('1', 2, 10) + 0,	CONV('0', 2, 10) + 0,	1,	'2022-06-03 20:26:43');

DROP TABLE IF EXISTS `water`;
CREATE TABLE `water` (
  `id` int NOT NULL AUTO_INCREMENT,
  `longitude` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `latitude` varchar(24) NOT NULL,
  `homeWithWater` bit(1) NOT NULL,
  `waterMissedInAWeek` int NOT NULL,
  `hasWell` bit(1) NOT NULL,
  `hasSanitationProject` bit(1) NOT NULL,
  `user` int NOT NULL,
  `status` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `user` (`user`),
  CONSTRAINT `water_ibfk_7` FOREIGN KEY (`status`) REFERENCES `status` (`id`),
  CONSTRAINT `water_ibfk_8` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


-- 2024-10-27 14:59:50
