-- Adminer 4.8.1 MySQL 8.0.29 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `tebecity`;

SET NAMES utf8mb4;

CREATE TABLE `survey` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question01` varchar(1) NOT NULL,
  `question02` varchar(1) NOT NULL,
  `question03` varchar(1) NOT NULL,
  `question04` varchar(1) NOT NULL,
  `question05` varchar(1) NOT NULL,
  `createdAt` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- 2023-04-09 18:47:15
